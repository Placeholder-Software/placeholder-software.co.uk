﻿using System;
using Dissonance.Integrations.DarkRift2;
using Dissonance.Networking;

namespace DissonanceServerPlugin
{
    /// <summary>
    /// We don't need a client since this is a server plugin. We just need something to satisfy the `TClient` type parameter of `BaseServer`
    /// </summary>
    public class DarkRift2Client
        : BaseClient<DarkRift2Server, DarkRift2Client, DarkRift2Peer>
    {
        public DarkRift2Client()
        {
            throw new NotSupportedException("Cannot create client in Dark Rift server");
        }
    }
}
