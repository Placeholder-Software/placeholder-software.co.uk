﻿

// ReSharper disable once CheckNamespace (Justification: Faking something which we don't need on the server side)
namespace Dissonance.Networking.Client
{
    public class PeerVoiceReceiver
    {
    }
}
