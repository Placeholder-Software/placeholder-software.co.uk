﻿using System;
using DarkRift.Server;
using Dissonance;
using Dissonance.Datastructures;
using Dissonance.Integrations.DarkRift2;

namespace DissonanceServerPlugin
{
    public class DissonanceVoiceServerPlugin
        : Plugin
    {
        [NotNull] public override Version Version => new Version(1, 0, 0);

        public override bool ThreadSafe => false;

        private readonly ConcurrentPool<byte[]> _buffers = new ConcurrentPool<byte[]>(10, () => new byte[4096]);

        private readonly DarkRift2Server _dissonanceServer;

        public DissonanceVoiceServerPlugin(PluginLoadData pluginLoadData)
            : base(pluginLoadData)
        {
            Log.WriteEvent = WriteEvent;

            _dissonanceServer = new DarkRift2Server();

            ClientManager.ClientConnected += ClientConnected;
            ClientManager.ClientDisconnected += ClientDisconnected;
        }

        private void ClientConnected(object sender, [NotNull] ClientConnectedEventArgs e)
        {
            e.Client.MessageReceived += MessageReceived;
        }

        private void ClientDisconnected(object sender, [NotNull] ClientDisconnectedEventArgs e)
        {
            _dissonanceServer.ClientDisconnected(new DarkRift2Peer(e.Client));
        }

        private void MessageReceived(object sender, [NotNull] MessageReceivedEventArgs e)
        {
            var buffer = _buffers.Get();
            try
            {
                using (var message = e.GetMessage())
                {
                    var packet = DarkRift2Helpers.ReadPacket(message, buffer);
                    if (packet.HasValue)
                        _dissonanceServer.NetworkReceivedPacket(new DarkRift2Peer(e.Client), packet.Value);
                }
            }
            finally
            {
                _buffers.Put(buffer);
            }
        }
    }
}
