﻿using System;
using System.Linq;
using DarkRift;
using DarkRift.Server;
using Dissonance.Integrations.DarkRift2.Demo;

namespace DissonanceDemoPlugin
{
    public class DissonanceDemoPlugin
        : Plugin
    {
        public override Version Version => new Version(1, 0, 0);

        public override bool ThreadSafe => false;

        public DissonanceDemoPlugin(PluginLoadData pluginLoadData)
            : base(pluginLoadData)
        {
            ClientManager.ClientConnected += ClientConnected;
            ClientManager.ClientDisconnected += ClientDisconnected;
        }

        private void ClientDisconnected(object sender, ClientDisconnectedEventArgs e)
        {
            //Broadcast leave message to all clients
            using (var w = DarkRiftWriter.Create())
            {
                w.Write(e.Client.ID);

                using (var m = Message.Create(Tags.DeleteRemotePlayer, w))
                {
                    foreach (var c in ClientManager.GetAllClients())
                        c.SendMessage(m, SendMode.Reliable);
                }
            }
        }

        private void ClientConnected(object sender, ClientConnectedEventArgs e)
        {
            e.Client.MessageReceived += MessageReceived;
        }

        private void MessageReceived(object sender, MessageReceivedEventArgs e)
        {
            using (var message = e.GetMessage())
            {
                if (message.Tag == Tags.PositionUpdateTag)
                    ReadPositionUpdate(e.Client, message);
            }
        }

        private void ReadPositionUpdate(IClient sender, Message message)
        {
            //Re-Broadcast the position update to all other clients
            foreach (var c in ClientManager.GetAllClients().Where(x => x != sender))
                c.SendMessage(message, SendMode.Reliable);
        }
    }
}
