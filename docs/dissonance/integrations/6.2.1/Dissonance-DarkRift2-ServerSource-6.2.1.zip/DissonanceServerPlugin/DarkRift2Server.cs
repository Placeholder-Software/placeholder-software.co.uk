﻿using System;
using DarkRift;
using Dissonance.Integrations.DarkRift2;
using Dissonance.Networking;

namespace DissonanceServerPlugin
{
    public class DarkRift2Server
        : BaseServer<DarkRift2Server, DarkRift2Client, DarkRift2Peer>
    {
        protected override void ReadMessages()
        {
            //Do nothing, we receive messages elsewhere through an event handler
        }

        private static void Send(DarkRift2Peer connection, ArraySegment<byte> packet, SendMode mode)
        {
            using (var writer = DarkRift2Helpers.WritePacket(packet))
            using (var msg = Message.Create(DarkRift2Helpers.DissonanceMessageTag, writer))
                connection.Client.SendMessage(msg, mode);
        }

        protected override void SendReliable(DarkRift2Peer connection, ArraySegment<byte> packet)
        {
            Send(connection, packet, SendMode.Reliable);
        }

        protected override void SendUnreliable(DarkRift2Peer connection, ArraySegment<byte> packet)
        {
            Send(connection, packet, SendMode.Unreliable);
        }

        public new void ClientDisconnected(DarkRift2Peer peer)
        {
            base.ClientDisconnected(peer);
        }
    }
}
