﻿using System;
using System.Collections.Generic;
using Dissonance.Networking.Client;

// ReSharper disable once CheckNamespace
namespace Dissonance.Networking
{
    public class BaseClient<TServer, TClient, TPeer>
        : IClient<TPeer>
        where TPeer : struct
        where TServer : BaseServer<TServer, TClient, TPeer>
        where TClient : BaseClient<TServer, TClient, TPeer>
    {
        public void SendReliable(ArraySegment<byte> arraySegment)
        {
            throw new NotSupportedException("Cannot create client on Dark Rift Server");
        }

        public void SendUnreliable(ArraySegment<byte> arraySegment)
        {
            throw new NotSupportedException("Cannot create client on Dark Rift Server");
        }

        public void SendReliableP2P(List<ClientInfo<TPeer?>> destinations, ArraySegment<byte> packet)
        {
            throw new NotSupportedException("Cannot create client on Dark Rift Server");
        }

        public void SendUnreliableP2P(List<ClientInfo<TPeer?>> destinations, ArraySegment<byte> packet)
        {
            throw new NotSupportedException("Cannot create client on Dark Rift Server");
        }
    }
}
