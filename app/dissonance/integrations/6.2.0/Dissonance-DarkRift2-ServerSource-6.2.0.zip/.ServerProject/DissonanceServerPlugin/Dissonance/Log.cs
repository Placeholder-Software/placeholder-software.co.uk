﻿using System;
using DarkRift;

// ReSharper disable once CheckNamespace (Justification: must be in this namespace to mock the normal Dissonance logging)
namespace Dissonance
{
    /// <summary>
    /// Dissonance using a Logging system which wraps the Unity logging system (see Log.cs in Dissonance).
    /// This replaces that with the same external interface, but which can run in a dark rift server context
    /// </summary>
    public static class Logs
    {
        [NotNull] public static Log Create(LogCategory category, string name)
        {
            return new Log(category, name);
        }
    }

    public class Log
    {
        public Log(LogCategory category, string name)
        {
        }

        public static Action<string, LogType, Exception> WriteEvent { get; set; }

        public void Trace(string message)
        {
            WriteEvent(message, LogType.Trace, null);
        }

        public void Trace<T0, T1>([NotNull] string message, T0 param0, T1 param1)
        {
            WriteEvent(string.Format(message, param0, param1), LogType.Trace, null);
        }

        public void Debug([NotNull] string message)
        {
            WriteEvent(message, LogType.Trace, null);
        }

        internal void Debug<T0>([NotNull] string message, T0 param0)
        {
            WriteEvent(string.Format(message, param0), LogType.Trace, null);
        }

        internal void Debug<T0, T1, T2, T3>([NotNull] string message, T0 param0, T1 param1, T2 param2, T3 param3)
        {
            WriteEvent(string.Format(message, param0, param1, param2, param3), LogType.Trace, null);
        }

        public void Info([NotNull] string message)
        {
            WriteEvent(message, LogType.Info, null);
        }

        public void Info<T0>([NotNull] string message, T0 param0)
        {
            WriteEvent(string.Format(message, param0), LogType.Info, null);
        }

        internal void Warn([NotNull] string message)
        {
            WriteEvent(message, LogType.Warning, null);
        }

        public void Warn<T0>([NotNull] string message, T0 param0)
        {
            WriteEvent(string.Format(message, param0), LogType.Warning, null);
        }

        public void Warn<T0, T1>([NotNull] string message, T0 param0, T1 param1)
        {
            WriteEvent(string.Format(message, param0, param1), LogType.Warning, null);
        }

        public void Error([NotNull] string message)
        {
            WriteEvent(message, LogType.Error, null);
        }

        internal void Error<T0>([NotNull] string message, T0 param0)
        {
            WriteEvent(string.Format(message, param0), LogType.Error, null);
        }

        [ContractAnnotation("assertion:true => false; assertion:false => true")]
        public bool AssertAndLogError<T0>(bool assertion, string guid, string message, T0 param0)
        {
            if (!assertion)
                Error($"{guid}: {string.Format(message, param0)}");

            return !assertion;
        }

        [ContractAnnotation("assertion:false => halt")]
        public void AssertAndThrowPossibleBug(bool assertion, string guid, string message)
        {
            if (!assertion)
                throw CreatePossibleBugException(message, guid);
        }

        [ContractAnnotation("assertion:false => halt")]
        internal void AssertAndThrowPossibleBug<T0>(bool assertion, string guid, string format, T0 param0)
        {
            if (!assertion)
                throw CreatePossibleBugException(string.Format(format, param0), guid);
        }

        [NotNull] public Exception CreatePossibleBugException(string message, string guid)
        {
            return new Exception($"Possible Bug. GUID:{guid}. MSG:{message}");
        }

        [ContractAnnotation("assertion:true => false; assertion:false => true")]
        public bool AssertAndLogWarn(bool assertion, string message)
        {
            if (!assertion)
                Warn(message);

            return !assertion;
        }
    }
}
